/**
 * 
 */
package com.resturant.project;

/**
 * 
 */
public class ResturantIdNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResturantIdNotFoundException(String message) {
		super(message);
	}
	
	

}
