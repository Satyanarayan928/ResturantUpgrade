/**
 * 
 */
package com.resturant.project;

/**
 * 
 */
public class ItemNameNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemNameNotFoundException(String message) {
		super(message);
	}
	
	

}
