package com.resturant.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResturantStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResturantStudentApplication.class, args);
	}

}
