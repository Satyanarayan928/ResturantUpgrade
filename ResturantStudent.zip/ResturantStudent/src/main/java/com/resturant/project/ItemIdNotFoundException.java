package com.resturant.project;

public class ItemIdNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemIdNotFoundException(String message) {
		super(message);
	}
	
	

}
