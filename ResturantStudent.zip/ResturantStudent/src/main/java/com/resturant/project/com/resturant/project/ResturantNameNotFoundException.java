package com.resturant.project;

public class ResturantNameNotFoundException extends Throwable {
    public ResturantNameNotFoundException(String message) {
    }
}
