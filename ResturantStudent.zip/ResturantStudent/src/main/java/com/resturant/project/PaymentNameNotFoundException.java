/**
 * 
 */
package com.resturant.project;

/**
 * 
 */
public class PaymentNameNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentNameNotFoundException(String message) {
		super(message);
	}
	
	

}
