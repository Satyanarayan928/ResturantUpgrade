package com.resturant.project;

public class CustomerNameNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerNameNotFoundException(String name) {
		super(name);
	}
	
	

}
